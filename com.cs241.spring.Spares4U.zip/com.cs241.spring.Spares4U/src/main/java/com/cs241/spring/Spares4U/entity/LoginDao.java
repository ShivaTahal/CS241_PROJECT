package com.cs241.spring.Spares4U.entity;

import java.sql.*;  

public class LoginDao {  
public static boolean validate(String name,String pass){  
	boolean status=false;  
	try{  
		Class.forName("com.mysql.jdbc.Driver"); 
		
		Connection con=DriverManager.getConnection(  
		"jdbc:mysql://localhost:3306/db","root","");  
		
		PreparedStatement ps=con.prepareStatement(  
		"SELECT * FROM employee WHERE Email =? AND Password =?"); 
		
		ps.setString(1,name);  
		ps.setString(2,pass);  
		
		ResultSet rs=ps.executeQuery(); 
		
		status=rs.next();  
		
	    //System.out.println(status);
	    
	}catch(Exception e){
		System.out.println(e);
	}  
	return status;  
	}  
}
