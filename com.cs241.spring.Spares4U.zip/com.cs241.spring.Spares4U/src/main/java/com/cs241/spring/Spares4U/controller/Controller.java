package com.cs241.spring.Spares4U.controller;

public @interface Controller {

}
