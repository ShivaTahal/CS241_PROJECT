package com.cs241.spring.Spares4U.entity;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class Report {
	 public static void report(List<Product> ProductList) throws IOException {
		 int short_counter = 0, surplusCounter = 0;
		 for(int i = 0; i < ProductList.size(); i++) {
				if(ProductList.get(i).getShort_surplus()  > 0) {
					short_counter++;
				}
				else if(ProductList.get(i).getShort_surplus() < 0) {
					surplusCounter++;
				}
			}
		 
			FileWriter fileWriter = new FileWriter("C:/com.cs241.spring.Spares4U/src/main/resources/templates/web/Report.html");
			File file = new File ("C:/com.cs241.spring.Spares4U/src/main/resources/templates/web/Report.html");
			file.delete();
			
			PrintWriter printWriter = new PrintWriter(fileWriter);
			printWriter.print("<html>"
					+ "<style>\r\n"
					+ "		.heading {\r\n"
					+ "		\r\n"
					+ "			padding: 10px;\r\n"
					+ "			border: 1px solid black;\r\n"
					+ "			margin: 0;\r\n"
					+ "			overflow: hidden;\r\n"
					+ "  			background-color: #333;\r\n"
					+ "  			position: fixed;\r\n"
					+ "  			top: 0;\r\n"
					+ "  			width: 100%;\r\n"
					+ "		}\r\n"
					+ "	\r\n"
					+ "\r\n"
					+ "		.button {\r\n"
					+ "			background-color: #4CAF50;\r\n"
					+ "			border: none;\r\n"
					+ "			color: white;\r\n"
					+ "			padding: 15px 32px;\r\n"
					+ "			text-align: center;\r\n"
					+ "			text-decoration: none;\r\n"
					+ "			display: inline-block;\r\n"
					+ "			font-size: 16px;\r\n"
					+ "			margin: 4px 2px;\r\n"
					+ "			cursor: pointer;\r\n"
					+ "		}\r\n"
					+ "\r\n"
					+ "		.button2 {\r\n"
					+ "			background-color: #008CBA;\r\n"
					+ "		}\r\n"
					+ "		.botton3{\r\n"
					+ "			background-color: #FF0000;	\r\n"
					+ "		}\r\n"
					+ "\r\n"
					+ "		.space {\r\n"
					+ "			margin-left: 1000px;\r\n"
					+ "		}\r\n"
					+ "\r\n"
					+ "		.space1 {\r\n"
					+ "			margin-right: 1080px;\r\n"
					+ "		}\r\n"
					+ "\r\n"
					+ "		.space2 {\r\n"
					+ "			margin-right: 1000px;\r\n"
					+ "		}\r\n"
					+ "		.navbar {\r\n"
					+ "  			overflow: hidden;\r\n"
					+ "  			background-color: #333;\r\n"
					+ "  			position: fixed;\r\n"
					+ "  			top: 0;\r\n"
					+ "  			width: 100%;\r\n"
					+ "		}\r\n"
					+ "		table {\r\n"
					+ "			width:100%;\r\n"
					+ "		}\r\n"
					+ "		table, th, td {\r\n"
					+ " 			border: 1px solid black;\r\n"
					+ "			border-collapse: collapse;\r\n"
					+ "		}\r\n"
					+ "		th, td {\r\n"
					+ "			padding: 15px;\r\n"
					+ "			text-align: left;\r\n"
					+ "		}\r\n"
					+ "		#t01 tr:nth-child(even) {\r\n"
					+ "	"
					+ "		}\r\n"
					+ "		#t01 tr:nth-child(odd) {\r\n"
					+ "	"
					+ "		}\r\n"
					+ "		#t01 th {\r\n"
					+ "			background-color: black;\r\n"
					+ "			color: white;\r\n"
					+ "		}\r\n"
					+ "</style>"
					+ "<body bgcolor = \"powderblue\">"
					+ "<h1 style = \"font-family:georgia,garamond,serif;font-size:50;font-style:italic; color:red; text-align:center;\">Spares4U Corp's IMS Short/Surplus Report</h1>");
			printWriter.print("<button class=\"button\" onclick=\"window.print()\">Print this page</button>");
			printWriter.print("<h2>Number of items: " + ProductList.size() + "</h2>");
			printWriter.print("<h2>Product on surplus: " + surplusCounter + "</h2>");
			printWriter.print("<table id = \"t01\"><tr> <th>#</th> <th>ID</th> <th>Product Name</th> <th>Description</th></tr>");
			int j = 1;
			for(int i = 0; i < ProductList.size(); i++) {
				if(ProductList.get(i).getShort_surplus() < 0) {
					printWriter.print("<tr><td>" + j +"</td><td>" + ProductList.get(i).getProduct_id() + "</td><td>" +ProductList.get(i).getProduct_name() + "</td><td>"
							+ "Clear " + (ProductList.get(i).getShort_surplus() * -1) + " items from the inventory.</td></tr>");
					j++;
				}
			}
			
			
			printWriter.print("</table> <h2>Product on short: " + short_counter + "</h2>");
			printWriter.print("<table id = \"t01\"><tr> <th>#</th> <th>ID</th> <th>Product Name</th> <th>Description</th></tr>");
			int k = 1;
			for(int i = 0; i < ProductList.size(); i++) {
				if(ProductList.get(i).getShort_surplus()  > 0) {
					if(ProductList.get(i).getShort_surplus()  >= 10) {
						printWriter.print("<tr  bgcolor = \"orange\"><td>" + k +"</td><td>" + ProductList.get(i).getProduct_id() + "</td><td>" +ProductList.get(i).getProduct_name() + "</td><td>"
								+ "Order " + (ProductList.get(i).getShort_surplus()) + " items more from the supplier.</td></tr>");
						k++;
					}
					else {
						printWriter.print("<tr  bgcolor = \"yellow\"><td>" + k +"</td><td>" + ProductList.get(i).getProduct_id() + "</td><td>" +ProductList.get(i).getProduct_name() + "</td><td>"
								+ "Order " + (ProductList.get(i).getShort_surplus()) + " items more from the supplier.</td></tr>");
						k++;
					}
				}
			}
			printWriter.print("</table>");
			printWriter.print("<a href=\"Welcome\" class=\"button  \">Menu</a>\r\n"
					+ "<a href=\"login\" class=\" button \">Log out</a>");
			printWriter.print("</body></html>");
			printWriter.close();
			fileWriter.close();
			
	}
}
