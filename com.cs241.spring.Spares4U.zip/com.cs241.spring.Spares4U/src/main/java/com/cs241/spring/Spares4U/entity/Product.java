package com.cs241.spring.Spares4U.entity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "product")
// why serializable ?? every entity in JPA is automatically-serializable,  connection between different networks
public class Product implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // assign a unique value to your identity field automatically
	
	@Column(name="product_id")
    private int product_id;
	@Column(name="product_name")
    private String product_name;
	@Column(name="manufacture_date")
    private String manufacture_date;
	@Column(name="quantity")
    private int quantity;
	@Column(name="brand_name")
    private String brand_name;
	@Column(name="company_name")
    private String company_name;
	@Column(name="quantOnHand")
    private int quantOnHand;
	@Column(name="short_surplus")
    private int short_surplus;
	
	
	
	public int getShort_surplus() {
		return short_surplus;
	}
	public void setShort_surplus(int short_surplus) {
		this.short_surplus = short_surplus;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getManufacture_date() {
		return manufacture_date;
	}
	public void setManufacture_date(String manufacture_date) {
		this.manufacture_date = manufacture_date;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getBrand_name() {
		return brand_name;
	}
	public void setBrand_name(String brand_name) {
		this.brand_name = brand_name;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public int getQuantOnHand() {
		return quantOnHand;
	}
	public void setQuantOnHand(int quantOnHand) {
		this.quantOnHand = quantOnHand;
	}
	
}


	