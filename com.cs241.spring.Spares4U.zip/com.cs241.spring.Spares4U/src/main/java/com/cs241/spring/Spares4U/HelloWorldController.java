package com.cs241.spring.Spares4U;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

//view -> send request -> controller -> renders -> view
@Controller
public class HelloWorldController {
	@RequestMapping("/")
	@ResponseBody
	String index() {
		return "Spares4U Corp";
	}
}
