package com.cs241.spring.Spares4U.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cs241.spring.Spares4U.entity.Product;


@Repository
public interface ProductRepository extends JpaRepository<Product,Long> {
	@Query(value = "SELECT i FROM Product i ")List<Product> findAll();
	@Query(value = "SELECT i FROM Product i ORDER BY product_id DESC")List<Product> findAllDSC();
	@Query(value = "SELECT i FROM Product i ORDER BY brand_name ASC")List<Product> orderByBrand();
	@Query(value = "SELECT i FROM Product i ORDER BY product_name ASC")List<Product> orderByProduct();
	@Query(value = "SELECT i FROM Product i ORDER BY quantity ASC")List<Product> orderByQuantity();
	@Query(value = "SELECT i FROM Product i")List<Product> findByID(int i);
}
 