package com.cs241.spring.Spares4U.controller;

import java.io.IOException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.cs241.spring.Spares4U.entity.LoginDao;
import com.cs241.spring.Spares4U.entity.Product;
import com.cs241.spring.Spares4U.entity.Report;

import com.cs241.spring.Spares4U.repository.ProductRepository;


@Controller
public class WebController {
	@Autowired
	
	ProductRepository ProductRepository;

	@RequestMapping(value = "/login", method = {RequestMethod.GET, RequestMethod.POST})
    public String login(@RequestParam(required=false,name="email") String username,@RequestParam(required=false,name="pass") String userpass) {
		boolean log = false;
		if(LoginDao.validate(username, userpass)) {
			return "web/Welcome";
		}
		else if(!LoginDao.validate(username, userpass) && username != null)
			
			return ("web/loginFailed");
		else
			return ("web/login");
    }
	
	@RequestMapping("/Welcome")
    public String homePage() {
		return "web/Welcome";
    }
	
	@RequestMapping("/InitiateStockTake")
    public String submitQuantity(Product product, Model model, RedirectAttributes ra, @RequestParam(name = "submitted", required = false) boolean submitted) {
		model.addAttribute("obj_product",this.ProductRepository.findAll());
		return "web/InitiateStockTake";
    }
	@GetMapping("/Brand")
    public String Sortbybrand(Model model) {
		model.addAttribute("obj_product",this.ProductRepository.orderByBrand());
       return "web/InitiateStockTake";
    }
	@GetMapping("/Product")
    public String Sortbyproduct(Model model) {
		model.addAttribute("obj_product",this.ProductRepository.orderByProduct());
       return "web/InitiateStockTake";
    }
	@GetMapping("/Quantity")
    public String Sortbyquantity(Model model) {
		model.addAttribute("obj_product",this.ProductRepository.orderByQuantity());
       return "web/InitiateStockTake";
    }
	@GetMapping("/Report")
    public String Report(Model model) throws IOException {
		List<Product> ProductList = ProductRepository.findAll();
		Report.report(ProductList);
       return "web/view_page";
    }
	
	@GetMapping("/viewReport")
    public String getStockTake(Model model) {
		
       return "web/Report";
    }
}
    
    
    
    
    
    
    