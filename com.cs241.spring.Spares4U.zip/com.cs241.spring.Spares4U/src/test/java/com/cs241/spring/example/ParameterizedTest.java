package com.cs241.spring.example;

import static org.junit.Assert.assertEquals;
import java.util.List;
import org.assertj.core.util.Arrays;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import com.cs241.spring.Spares4U.entity.LoginDao;

@RunWith(Parameterized.class)
public class ParameterizedTest{
	@Parameterized.Parameter(0)
	public String a;
	@Parameterized.Parameter(1)
	public String b;
	@Parameterized.Parameter(2)
	public boolean result;
	
	@Parameterized.Parameters
	public static List<Object> Collection(){
		Object[][] data = new Object[][] {{"admin@s4u.com", "admin", true},{"lookfor@aStored.email.inDB","admin", false}, {"dfdfd","admin", false}};
		return Arrays.asList(data);
	}
	
	@Test
	public void TestIt() {
		assertEquals(result, LoginDao.validate(a, b));
		System.out.println("Result " + result + " " + LoginDao.validate(a, b));
	}
}